/*

File: MainViewController.m
Abstract: Controller class for the "main" view (visible at app start).

*/

#import "MainViewController.h"

@implementation MainViewController

@synthesize flipDelegate, updateTextView, webView, startStopButton, spinner;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
	if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
		isCurrentlyUpdating = NO;
		isCurrentlySending = NO;
		firstUpdate = YES;
	}
	return self;
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
	// Release anything that's not essential, such as cached data
}


- (void)dealloc {
	[updateTextView release];
    webView.delegate = nil;
	[webView release];
	[startStopButton release];
	[spinner release];
    
	[super dealloc];
}


// Appends some text to the main text view
// If this is the first update, it will replace the existing text
-(void)addTextToLog:(NSString *)text {
	if (firstUpdate) {
		updateTextView.text = text;
		firstUpdate = NO;
	} else {
		updateTextView.text = text;//[NSString stringWithFormat:@"%@-----\n\n%@", updateTextView.text, text];
		//[updateTextView scrollRangeToVisible:NSMakeRange([updateTextView.text length], 0)]; // scroll to the bottom on updates
	}
}

// Called when the view is loading for the first time only
// If you want to do something every time the view appears, use viewWillAppear or viewDidAppear
- (void)viewDidLoad {
	[MyCLController sharedInstance].delegate = self;
    webView.delegate = self;

    // Check to see if the user has disabled location services all together
    // In that case, we just print a message and disable the "Start" button
    if ( ! [MyCLController sharedInstance].locationManager.locationServicesEnabled ) {
        [self addTextToLog:NSLocalizedString(@"NoLocationServices", @"User disabled location services")];
        startStopButton.enabled = NO;
    } else {
		[self startStopButtonPressed: self.flipDelegate];
    }
}

#pragma mark ---- control callbacks ----

// Tells the root view, via a delegate, to flip over to the FlipSideView
- (IBAction)infoButtonPressed:(id)sender {
	[self.flipDelegate toggleView:self];
}

// Called when the "start/stop" button is pressed
-(IBAction)startStopButtonPressed:(id)sender {
	if (isCurrentlyUpdating) {
		[[MyCLController sharedInstance].locationManager stopUpdatingLocation];
		isCurrentlyUpdating = NO;
        isCurrentlySending = NO;
		[startStopButton setTitle:NSLocalizedString(@"StartButton", @"Start")];
        //[webView stopLoading];
		[spinner stopAnimating];
	} else {
		[[MyCLController sharedInstance].locationManager startUpdatingLocation];
		isCurrentlyUpdating = YES;
		[startStopButton setTitle:NSLocalizedString(@"StopButton", @"Stop")];
		[spinner startAnimating];
	}
}

#pragma mark ---- delegate methods for the MyCLController class ----

-(void)newLocationUpdate:(NSString *)text {
        [self addTextToLog:text];
}

-(void)phpUpdate:(NSString *)url {
	// create the request
    if (isCurrentlySending == NO) {
    isCurrentlySending = YES;
    //[[MyCLController sharedInstance].locationManager stopUpdatingLocation]; // warten, bis Seite geladen ist
	NSURLRequest *theRequest=[NSURLRequest requestWithURL:[NSURL URLWithString:url]
											  cachePolicy:NSURLRequestReturnCacheDataElseLoad
										  timeoutInterval:30.0];
	[webView loadRequest:theRequest];
    }
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    isCurrentlySending = NO;
	if (isCurrentlyUpdating) { // weitermachen!
        //[[MyCLController sharedInstance].locationManager startUpdatingLocation];
    }
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
    isCurrentlySending = NO;
	if (isCurrentlyUpdating) { // weitermachen!
        //[[MyCLController sharedInstance].locationManager startUpdatingLocation];
    }
    
    // inform the user
    //[self addTextToLog:[NSString stringWithFormat: @"Load failed! Error - %@",
    //                    [error localizedDescription]]];
}
-(void)newError:(NSString *)text {
	[self addTextToLog:text];
}

@end
