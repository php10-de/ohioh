/*

File: MainViewController.h
Abstract: Controller class for the "main" view (visible at app start).


*/

#import "MyCLController.h"
#import "RootViewController.h"

@interface MainViewController : UIViewController <MyCLControllerDelegate,UIWebViewDelegate> {
	IBOutlet UITextView *updateTextView;
    IBOutlet UIWebView *webView;
	IBOutlet UIBarButtonItem *startStopButton;
	IBOutlet UIActivityIndicatorView *spinner;
	BOOL isCurrentlyUpdating;
	BOOL isCurrentlySending;
	BOOL firstUpdate;
	id flipDelegate;
    //NSURLRequest *theRequest;
}

@property (nonatomic,assign) id <MyFlipControllerDelegate> flipDelegate;
@property (nonatomic, retain) UITextView *updateTextView;
@property (nonatomic, retain) UIWebView *webView;
@property (nonatomic, retain) UIBarButtonItem *startStopButton;
@property (nonatomic, retain) UIActivityIndicatorView *spinner;
//@property (nonatomic, retain) NSURLRequest *theRequest;

- (IBAction)infoButtonPressed:(id)sender;
- (IBAction)startStopButtonPressed:(id)sender;

@end
